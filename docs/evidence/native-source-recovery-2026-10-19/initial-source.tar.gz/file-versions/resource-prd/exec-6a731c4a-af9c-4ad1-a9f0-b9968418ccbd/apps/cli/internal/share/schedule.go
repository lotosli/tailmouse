package share
import("context";"tailmouse/apps/cli/internal/flow")
type scheduledStream struct{Stream;ctx context.Context;scheduler *flow.Scheduler;priority int}
func(s *scheduledStream)Write(b []byte)(int,error){return s.scheduler.Write(s.ctx,s.priority,func()(int,error){return s.Stream.Write(b)})}
func(s *scheduledStream)bulk(){s.priority=3}
