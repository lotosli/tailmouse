package share
import(
 "context"
 "io"
 "net/http"
 "net/http/httptest"
 "strings"
 "sync/atomic"
 "testing"
)
func TestWebPreflightCookiesAndOriginContainment(t *testing.T){
 var hits atomic.Int64
 upstream:=httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){hits.Add(1);switch r.URL.Path{case "/login":http.SetCookie(w,&http.Cookie{Name:"session",Value:"synthetic",Path:"/",HttpOnly:true});w.WriteHeader(204);case "/private":if c,e:=r.Cookie("session");e!=nil||c.Value!="synthetic"{w.WriteHeader(401)}else{_,_=io.WriteString(w,"authenticated")};case "/redirect":http.Redirect(w,r,"http://forbidden.invalid/",302);default:_,_=io.Copy(w,r.Body)}}));defer upstream.Close()
 web,e:=NewWeb(context.Background(),upstream.URL+"/initial?q=1#section",false,"");if e!=nil{t.Fatal(e)};defer web.Close();if hits.Load()!=0{t.Fatal("preflight sent HTTP")};if web.InitialPath()!="/initial?q=1#section"{t.Fatal("initial navigation")}
 request:=func(member,path string)int{t.Helper();res,e:=web.Do(context.Background(),member,HTTPRequest{Type:"request",Method:"GET",Path:path},nil);if e!=nil{t.Fatal(e)};defer res.Body.Close();return res.StatusCode}
 if request("a","/login")!=204||request("a","/private")!=200||request("b","/private")!=401{t.Fatal("cookie isolation")}
 for _,path:=range []string{"https://forbidden.invalid/","//forbidden.invalid/","/\\forbidden","/.tailmouse/shim.js"}{if _,e:=web.Do(context.Background(),"a",HTTPRequest{Type:"request",Method:"GET",Path:path},nil);e!=ErrWebPolicy{t.Fatal("target escape accepted")}}
 if _,e=web.Do(context.Background(),"a",HTTPRequest{Type:"request",Method:"GET",Path:"/redirect"},nil);e!=ErrWebPolicy{t.Fatal("redirect escaped",e)}
 web.Forget("a");if request("a","/private")!=401{t.Fatal("revoked cookie retained")}
 response,e:=web.Do(context.Background(),"a",HTTPRequest{Type:"request",Method:"POST",Path:"/echo",Headers:[][2]string{{"Cookie","must-not-forward"},{"X-Test","ok"}}},strings.NewReader("hello"));if e!=nil{t.Fatal(e)};defer response.Body.Close();b,e:=io.ReadAll(response.Body);if e!=nil||string(b)!="hello"{t.Fatal("streaming body")}
}
func TestWebTLSAndValidation(t *testing.T){
 server:=httptest.NewTLSServer(http.HandlerFunc(func(http.ResponseWriter,*http.Request){t.Error("unexpected HTTP preflight")}));defer server.Close()
 if _,e:=NewWeb(context.Background(),server.URL,false,"");e!=ErrWebTLS{t.Fatal("untrusted TLS accepted")}
 if _,e:=NewWeb(context.Background(),"http://0.0.0.0:8080",false,"");e!=ErrConfig{t.Fatal("wildcard accepted")}
 for _,method:=range []string{"CONNECT","TRACE","G ET"}{web,e:=NewWeb(context.Background(),"http://127.0.0.1:1",false,"");if e!=nil{t.Fatal(e)};if _,e=web.Do(context.Background(),"a",HTTPRequest{Type:"request",Method:method,Path:"/"},nil);e!=ErrWebPolicy{t.Fatal("unsafe method")};web.Close()}
 if canInject(http.Header{"Content-Security-Policy":[]string{"default-src 'none'; script-src 'nonce-abc'"}}){t.Fatal("CSP bypass")};if !canInject(http.Header{"Content-Security-Policy":[]string{"default-src 'self'"}}){t.Fatal("same-origin scripts rejected")}
 if safeHeader("Bad\nName","ok")||safeHeader("X-Test","x\r\ny")||!blockedHeader("Proxy-Authorization"){t.Fatal("header validation")}
}
