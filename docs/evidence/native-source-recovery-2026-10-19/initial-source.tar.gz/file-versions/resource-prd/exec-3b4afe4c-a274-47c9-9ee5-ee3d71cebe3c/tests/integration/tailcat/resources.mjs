import { chromium } from 'playwright';
let input='';for await(const part of process.stdin)input+=part;
const {url}=JSON.parse(input);input='';
let stage='launch';let browser;
try {
  browser=await chromium.launch({chromiumSandbox:true,args:['--host-resolver-rules=MAP *.tailmouse.test 127.0.0.1, MAP *.tailmouse.invalid 127.0.0.1','--no-proxy-server']});
  const context=await browser.newContext({ignoreHTTPSErrors:true});const page=await context.newPage();
  page.setDefaultTimeout(20000);
  stage='navigation';await page.goto(url,{waitUntil:'domcontentloaded'});
  stage='admission';await page.getByText('Connected · encrypted Tailcat over DERP',{exact:true}).waitFor({timeout:70000});
  stage='terminal';await page.getByText('Connected to the same running process.',{exact:true}).waitFor();
  await page.getByLabel('Prepare terminal input').fill('resource-browser-probe\n');await page.getByRole('button',{name:'Send text without Enter',exact:true}).click();
  await page.waitForFunction(()=>document.querySelector('.workspace-terminal')?.textContent?.includes('resource-result:resource-browser-probe'));
  stage='preview';const preview=page.frameLocator('iframe[title="Isolated web preview"]').frameLocator('iframe[title="Shared application"]');
  await preview.getByRole('heading',{name:'Shared application',exact:true}).waitFor({timeout:40000});
  stage='isolation';await preview.getByText('Preview isolated',{exact:true}).waitFor();
  stage='socket';await preview.getByText('Socket hello',{exact:true}).waitFor();
  stage='http-write';await preview.getByRole('button',{name:'Save once',exact:true}).click();await preview.getByText('Saved once',{exact:true}).waitFor();
  stage='upload';await page.locator('input[type="file"]').setInputFiles({name:'sample.csv',mimeType:'text/csv',buffer:Buffer.from('resource upload\n'.repeat(10000))});
  await page.getByRole('button',{name:'Copy path',exact:true}).waitFor({timeout:30000});
  stage='explicit-insert';await page.getByRole('button',{name:'Insert into terminal field',exact:true}).click();
  if(!(await page.getByLabel('Prepare terminal input').inputValue()).includes('sample-'))throw new Error('receipt');
  stage='reload';await page.reload({waitUntil:'domcontentloaded'});await page.getByText('Connected · encrypted Tailcat over DERP',{exact:true}).waitFor({timeout:60000});
  stage='revocation';await page.evaluate(async()=>{await fetch('/__test/revoke',{method:'POST'});});
  await page.getByText('Access was revoked or the invitation is no longer valid.',{exact:true}).waitFor({timeout:25000});
  stage='close';await context.close();await browser.close();browser=undefined;
  process.stdout.write('resource stage: complete\n');
}catch{process.stderr.write(`resource stage: ${stage}\n`);process.exitCode=1;}finally{await browser?.close();}
