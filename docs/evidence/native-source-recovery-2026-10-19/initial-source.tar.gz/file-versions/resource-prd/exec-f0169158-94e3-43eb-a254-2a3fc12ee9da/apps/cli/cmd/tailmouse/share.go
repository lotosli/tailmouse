package main

import (
 "context"
 "encoding/json"
 "errors"
 "fmt"
 "io"
 "os"
 "strings"
 "sync"
 "time"

 "github.com/skip2/go-qrcode"
 "golang.org/x/term"
 "tailmouse/apps/cli/internal/share"
 tailcattransport "tailmouse/apps/cli/internal/transport/tailcat"
)
// shareOutput serializes the deliberate invitation surface with local PTY
// output. Diagnostic events never include the invitation or upstream errors.
type shareOutput struct{mu sync.Mutex;writer io.Writer}
func(w *shareOutput)Write(data []byte)(int,error){w.mu.Lock();defer w.mu.Unlock();return w.writer.Write(data)}
func runShare(ctx context.Context,stdin *os.File,args,environ []string,configDir string,stdout,stderr io.Writer,start transportStarter)(code int){
 options,help,err:=share.Parse(args,environ,configDir);if help{if _,err=io.WriteString(stdout,share.Help);err!=nil{return 6};return 0}
 if err!=nil{_,_=fmt.Fprintln(stderr,"Invalid sharing configuration. Run tailmouse",args[0],"--help.");return 2}
 isTTY:=stdin!=nil&&term.IsTerminal(int(stdin.Fd()))
 if options.Approval=="manual"&&!isTTY||options.JSON&&isTTY&&len(options.Argv)>0 {_,_=fmt.Fprintln(stderr,"Manual approval requires a local terminal; --json cannot use interactive local PTY input.");return 2}
 sessionCtx,cancel:=context.WithCancel(ctx);defer cancel()
 host,token,err:=share.NewHost(sessionCtx,options,environ);if err!=nil{_,_=fmt.Fprintln(stderr,"Resource initialization failed; check the command, directory, target and TLS policy.");return 3}
 defer func(){if err:=host.Close();err!=nil&&code==0{code=6}}()
 transportConfig:=tailcattransport.Config{BindPeer:true,PreferredRegion:options.DERPRegion,OnConnection:func(stream tailcattransport.ByteStream){host.Serve(stream,tailcattransport.PeerIdentity(stream))}}
 if options.DERPMap!=""{if strings.HasPrefix(options.DERPMap,"https://"){transportConfig.DERPMapURL=options.DERPMap}else{transportConfig.DERPMapFile=options.DERPMap}}
 transport,err:=start(sessionCtx,transportConfig);if err!=nil{_,_=fmt.Fprintln(stderr,"Tailcat transport could not start.");return 4}
 defer func(){closeCtx,closeCancel:=context.WithTimeout(context.Background(),2*time.Second);defer closeCancel();if err:=transport.Close(closeCtx);err!=nil&&code==0{code=4}}()
 address,err:=transport.CopyAddress();if err!=nil{return 4};defer clear(address)
 output:=&shareOutput{writer:stdout}
 publish:=func(secret string)error{
  link,e:=host.Invitation(string(address),secret);if e!=nil{return e}
  if options.JSON {event:=struct{Event string `json:"event"`;URL string `json:"url"`;TTL string `json:"ttl"`;Command string `json:"command"`}{"share.created",link,options.TTL.String(),options.Command};return json.NewEncoder(output).Encode(event)}
  rights:="observe and control";if options.ReadOnly{rights="observe terminal only"}
  _,e=fmt.Fprintf(output,"TailMouse %s — %s\nTTL: %s; members: %d; approval: %s\nTransport: encrypted Tailcat over DERP\nWeb scope: whole configured origin; uploads never execute automatically.\n%s\n",options.Command,rights,options.TTL,options.MaxClients,options.Approval,link);if e!=nil{return e}
  if file,ok:=stdout.(*os.File);ok&&term.IsTerminal(int(file.Fd()))&&!options.NoQR{qr,e:=qrcode.New(link,qrcode.Medium);if e!=nil{return errors.New("share QR could not be encoded")};if _,e=io.WriteString(output,qr.ToSmallString(false));e!=nil{return e}}
  if options.Open{if e=openShareBrowser(sessionCtx,link);e!=nil{_,_=fmt.Fprintln(stderr,"Could not open a local browser; use the displayed link.")}}
  return nil
 }
 host.Ready();if err=publish(token);err!=nil{return 6};token=""
 if options.JSON{if err=json.NewEncoder(output).Encode(struct{Event string `json:"event"`}{"share.ready"});err!=nil{return 6}}
 var console *leashLocalConsole
 var inputDone chan struct{}
 if isTTY&&!options.JSON {
  file,ok:=stdout.(*os.File);if !ok{return 3};console,err=openLeashConsole(stdin,file);if err!=nil{return 3}
  defer func(){if err:=console.Close();err!=nil&&code==0{code=6}}()
  if terminal:=host.Terminal();terminal!=nil {terminal.SetLocal(output);cols,rows,e:=console.Size();if e==nil&&cols>=20&&rows>=5{if terminal.LocalResize(sessionCtx,cols,rows)!=nil{return 3}}}
  inputDone=make(chan struct{});go func(){defer close(inputDone);manageShare(sessionCtx,console,host,output,publish,cancel)}()
 }
 <-host.Context().Done();cancel();if inputDone!=nil{<-inputDone}
 if options.JSON{if err=json.NewEncoder(output).Encode(struct{Event string `json:"event"`}{"share.closed"});err!=nil{return 6}}
 return 0
}
func manageShare(ctx context.Context,console *leashLocalConsole,host *share.Host,output io.Writer,publish func(string)error,cancel context.CancelFunc){
 buffer:=make([]byte,4096);menu:=false
 for{n,e:=console.ReadInput(ctx,buffer);if e!=nil{return};start:=0
  flush:=func(end int)bool{if end>start&&host.Terminal()!=nil{if host.Terminal().LocalInput(ctx,buffer[start:end])!=nil{return false}};return true}
  for i:=0;i<n;i++{key:=buffer[i];if menu{menu=false;switch key{case 0x1d:if host.Terminal()!=nil{if host.Terminal().LocalInput(ctx,[]byte{0x1d})!=nil{return}};case 'p':host.Pause();case 'a':host.Approve();case 'g':host.GrantControl();case 'r':host.TakeLocal();case 'i':if publish(host.Rotate())!=nil{cancel();return};case 'q':cancel();return};start=i+1;continue}
   if key==0x1d {if !flush(i){return};menu=true;start=i+1;if _,e:=io.WriteString(output,"\r\nTailMouse: [p] pause admission  [a] approve visitor  [g] grant input  [r] revoke input  [i] rotate invite  [q] end\r\n");e!=nil{return}}
  };if !menu&&!flush(n){return}
 }
}
