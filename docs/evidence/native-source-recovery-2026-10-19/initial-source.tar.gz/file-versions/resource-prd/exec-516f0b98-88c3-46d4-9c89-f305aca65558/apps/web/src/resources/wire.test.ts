import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { ResourceWire, CHUNK } from './wire.ts';
import { strictObject } from '../protocol/values.ts';
import type { ByteStream } from '../transport/tailcat/adapter.ts';
const corpus=JSON.parse(readFileSync(new URL('../../../../protocol/fixtures/tmouse-2.frames.json',import.meta.url),'utf8')) as {cases:{name:string;hex:string;valid:boolean}[]};
function fragmented(data:Uint8Array):ByteStream{let offset=0;return {read:async()=>offset<data.length?data.slice(offset,++offset):null,write:async()=>undefined,close:async()=>undefined};}
describe('TMOUSE/2 shared frame corpus',()=>{for(const entry of corpus.cases)it(entry.name,async()=>{const wire=new ResourceWire(fragmented(Uint8Array.from(Buffer.from(entry.hex,'hex'))));const decode=async()=>{const f=await wire.read();if(f.kind===1)strictObject(f.data);return f;};if(entry.valid)expect(await decode()).toBeDefined();else await expect(decode()).rejects.toThrow();});});
it('writes exact bounded frames and applies concurrent-write backpressure',async()=>{const values:Uint8Array[]=[];let release!:()=>void;const stream:ByteStream={read:async()=>null,write:async(data)=>{values.push(data);await new Promise<void>(resolve=>{release=resolve;});},close:async()=>undefined};const wire=new ResourceWire(stream);const sending=wire.json({type:'pong',seq:1});await expect(wire.write(2,new Uint8Array([1]))).rejects.toThrow('backpressure');release();await sending;expect(Buffer.from(values[0]!).toString('hex')).toBe(corpus.cases[0]!.hex);await expect(wire.write(2,new Uint8Array(CHUNK+1))).rejects.toThrow();await expect(wire.write(3,new Uint8Array([1]))).rejects.toThrow();});
