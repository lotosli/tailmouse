//go:build tailcatintegration && (linux || darwin)

package share

import (
 "os/exec"
 "testing"
)

// These are actual child TUIs under the owned PTY. The output overflow forces
// redraw recovery instead of permitting a passing historical-screen replay.
func TestResourceTUIRedraw(t *testing.T) {
 for _, fixture := range []struct{name, binary, command, marker, quit string}{
  {"vim", "vim.tiny", "printf 'resource-vim-marker\\n' > screen.txt; head -c 4194400 /dev/zero; exec env TERM=xterm-256color vim.tiny -u NONE -i NONE -n -N screen.txt", "resource-vim-marker", ":q!\r"},
  {"htop", "htop", "head -c 4194400 /dev/zero; exec env TERM=xterm-256color htop", "Tasks:", "q"},
 } {
  t.Run(fixture.name, func(t *testing.T) {
   if _, err := exec.LookPath(fixture.binary); err != nil { t.Skip("named TUI binary unavailable; platform acceptance remains pending") }
   h, token := terminalHost(t, false, fixture.command)
   _, w := welcomeHost(t, h, token, "peer")
   stream, first := terminalStream(t, h, w)
   readTerminalUntil(t, stream, fixture.marker)
   _ = stream.Close()
   next, redraw := terminalStream(t, h, w)
   if first.PID != redraw.PID || !redraw.HistoryLost || redraw.Recovery != "redraw" { t.Fatal("TUI did not retain process and request redraw") }
   readTerminalUntil(t, next, fixture.marker)
   if err := WriteFrame(next, DataFrame, []byte(fixture.quit)); err != nil { t.Fatal(err) }
  })
 }
}
