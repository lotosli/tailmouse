# Resource-sharing acceptance ledger

Source: [TailMouse PRD v1.0](TailMouse_PRD_v1.0.2026-10-16.zh-CN.md), SHA-256 `62c3283d778af3498e2ca463b0bd18dd7ce186f0792f554bebf7873943cc69ca`. The owner explicitly retained Escape. Evidence date: 2026-10-16. This document is a release checklist, not a claim that every platform or performance target passed.

## Reproduction and environment

The workspace uses Node 26.8.1, pnpm 11.25.0, Go 1.27.2, Chromium 151.0.7922.34 and the unchanged Tailcat v0.6.0 gitlink `790406204c002a6f109ef7c6a30a436601a1f6a8`. Browser acceptance runs against local DERP and local TLS fixtures, with Chromium's native sandbox enabled. Invitation and key material travels in memory/stdin only; failures emit bounded stage codes. No public relay is used for load tests.

```sh
pnpm gate:quick
pnpm gate
pnpm test:resources
```

Native boundary cases live in `apps/cli/internal/share/*_test.go` and `apps/cli/internal/flow/*_test.go`. Browser state, bridge and component cases live in `apps/web/src/resources/*test*` and `src/transport/tailcat/resource.test.ts`. `TestHermeticResourceWorkspace` crosses the native/Tailcat/Wasm/Worker/SW/browser boundary; it is not a mocked transport test. `TestResourceTUIRedraw` executes installed Vim and htop under real PTYs and forces the history-overflow recovery path.

Observed checkpoints: 286 browser tests passed at 90.18% statements, 87.90% branches, 87.82% functions and 91.91% lines before the later paste/recovery regressions were added. The focused native race checkpoint was 81.3% for share and 92.2% for flow. Both macOS architectures cross-compile; this does not prove native macOS/APFS behavior. Final gate evidence will replace this checkpoint after all changes settle.

## Section 20 evidence map

“Partial” identifies a specific missing scenario, not an implementation exemption. A unit boundary check is not promoted to physical-device, live-deployment or performance evidence.

| ID | Evidence and remaining verification |
| --- | --- |
| A-01 | Four-command parser/startup/help cases; real three-resource guest workflow. Separate four-command browser runs pending. |
| A-02 | Fragment validation, domain-only landing and native admission reject absent credentials. |
| A-03 | `TestHostGrantsBindPeerResourceAndGeneration`, strict shared frame corpus and invitation validation. |
| A-04 | Native rotation invalidates every member; real browser old-grant rejection. |
| A-05 | Fake-time TTL and native context cancellation; simultaneous active HTTP/input/upload expiry probe pending. |
| A-06 | Native member capacity and browser bounded retry; real capacity UI probe pending. |
| A-07 | Manual pending business streams rejected; disconnect releases pending slot. |
| A-08 | CLI manual approval without TTY fails before transport startup. |
| A-09 | Same-PID native reconnect, browser refresh, no implicit write replay; 100-cycle stress pending. |
| A-10 | Native grants remain authoritative; content dispose/SW/cache cleanup tests. Residual-worker end-to-end probe pending. |
| C-01 | Real Vim/htop history-overflow redraw and shell echo; resize/interrupt tested at native PTY boundary. Full browser TUI/physical-keyboard matrix pending. |
| C-02 | Direct readonly input, resize and interrupt attempts fail natively without changes. |
| C-03 | Native single controller/member selection; two real browsers controlling simultaneously pending. |
| C-04 | Local input revokes the remote seat before writing; explicit selected-member grant and local dimensions tested. |
| C-05 | Real PTY PID retained and bounded history/redraw tested. No complete VT snapshot is claimed after history overflow. |
| C-06 | UTF-8 streamed bytes, explicit preparation/insertion and captured multiline paste; physical Chinese IME/device acceptance pending. |
| C-07 | Natural exit preserves Dev; owned process cleanup and startup failure cases. Standalone 60-second retention is implemented. |
| C-08 | OSC 52 disabled, terminal link confirmation and bounded input. Malicious ANSI browser case expansion pending. |
| W-01 | Native target/size/origin/TLS parser tests and explicit remote-target policy. |
| W-02 | Initial path/query retained; UI/docs identify whole-origin scope. |
| W-03 | Real initial SW-controlled load and workspace refresh; direct application deep refresh expansion pending. |
| W-04 | Native HTTP streams and content SW bodyless statuses; multipart/Range cross-runtime expansion pending. |
| W-05 | Incremental SW response and 31-second idle SSE/cancel tests; sustained native-to-browser SSE pending. |
| W-06 | Vite 8.2.2 local fixture connects and hot-updates. Combined terminal/upload independence acceptance is being revalidated. |
| W-07 | Per-member native cookie jars, paths/expiry/HttpOnly/Secure/SameSite subset tested. Real two-account browser test pending. |
| W-08 | Fixed resource port, path/method validation, native authority checks and CONNECT denial. |
| W-09 | Frozen DNS addresses, no proxy environment, fixed Host/SNI, same-origin redirects; controlled DNS rebinding probe pending. |
| W-10 | Untrusted TLS rejection and explicit custom CA trust tested; verification never disabled in production. |
| W-11 | Restrictive header/meta CSP and X-Frame-Options fail closed; custom application SW compatibility warning pending. |
| W-12 | Real hostile preview cannot access parent DOM; exact origin/window/port tests reject forged CLI/receipt messages. |
| W-13 | Lost-write preview error reports unknown outcome and never replays; upstream-committed/lost-response integration pending. |
| W-14 | Static-only content hosting contract, business data only over authorized Tailcat streams; no webhook/public tunnel claim. |
| R-01 | Native zero/small/limit/hash cases and real 150 kB upload; default-limit browser probe pending. |
| R-02 | Declared-size overrun, per-file and cumulative reservations/traffic tests. |
| R-03 | Traversal, encoded separators, backslashes, control/hidden/device names, NFC and final UTF-8 length bounds tested. |
| R-04 | Anchored directory swap and open-inode atomic no-replace tests on Linux; native macOS filesystem execution pending. |
| R-05 | Random final suffix and no-overwrite commit; duplicate original names are independent attempts. |
| R-06 | Hash/storage failures and cleanup tested; actual disk-full/permission fault probe expansion pending. |
| R-07 | Native idempotent completion/status, browser lost-final-reply query; uncertain post-commit sync result retained without duplication. |
| R-08 | Cancel/close and authenticated abandoned partial cleanup; live/unknown files preserved. Process crash/active TTL integration pending. |
| R-09 | No browsing/read/delete/execute protocol operations; resource/channel grants fail closed. |
| R-10 | Receive only writes verified bytes; no extraction, command execution or agent invocation path. |
| R-11 | Canceled traffic and failed attempts remain charged; reservation release does not refund consumed bytes. |
| R-12 | 1 GiB explicit-limit, whole-process memory and equivalent raw Tailcat throughput comparison pending. |
| D-01 | Real single-invitation PTY/HTTP/WS/upload workflow over one browser transport identity. |
| D-02 | All legal pairs validated; disabled resources absent and no implicit shell. |
| D-03 | Native actual-name receipt, explicit copy, no automatic terminal use; real browser and component cases. |
| D-04 | Insert only prepares a bounded relative path; sending requires live native control, adds no Enter. |
| D-05 | Bounded scheduler, chunk ACKs, upload window and blocked-bulk control tests; measured simultaneous latency/memory pending. |
| D-06 | Native child exit keeps Dev alive; Web reprobe updates only Web state. Real server-restart workflow pending. |
| D-07 | Unique session/content origins and peer/session grants; simultaneous two-session browser probe pending. |
| D-08 | Preview capability rejects upload/CLI messages; receipt parsing rejects forged paths/digests before insertion. |
| D-09 | Local custom DERP + independently scoped static origins and unified JSON config; operator-owned public DNS/TLS deployment pending. |
| D-10 | TMOUSE/2 preface/version and frontend invitation-major validation reject mismatch without downgrade. |
| D-11 | Bounded safe native events and redacted bridge errors; no invitation in requests, arguments, DOM or diagnostic artifacts by design. Complete browser network capture audit pending. |
| D-12 | Mounted mobile tabs and background/BFcache suspension/recovery tests; physical iOS/Android lock/network-switch execution pending. |

## Performance and release limits

NFR-01 through NFR-07 require measured distributions and equivalent conditions, not a single successful workflow duration. The resource Wasm is approximately 26.86 MB raw and 5.03 MB Brotli; cold transfer, compilation and interactive latency remain separate measurements. Native revocation immediately invalidates grants and closes streams (NFR-08); remote notification timing must be reported separately. The eight-hour leak soak (NFR-09) and 100 reconnect test (NFR-10) are not yet completed.

The normal gate keeps the owner's four representative network profiles: RTT/jitter/loss/bandwidth `20/0/0/1024`, `80/20/1/256`, `300/20/0/64`, and `300/60/5/64` (ms/ms/%/Kbit/s). Large Cartesian matrices remain opt-in. Existing Escape/Leash impairment results do not automatically establish resource-sharing performance.

Latest two browser releases, native macOS execution, physical mobile devices, an operator-owned public deployment, ten external users and comparative product trials require separately recorded evidence. No external users have been contacted and no public deployment has been published as part of this change.
