# TailMouse

**Share a terminal. Share a web app. Receive files.**

One command. One link. Just a browser. TailMouse runs on the sharing host; guests need no account, client installation or Tailnet membership.

```sh
tailmouse cli -- codex
tailmouse web 8080
tailmouse receive ./uploads
tailmouse dev --web 5173 --receive ./uploads -- codex
```

The current product baseline is the [resource-sharing PRD](docs/evidence/TailMouse_PRD_v1.0.2026-10-16.zh-CN.md), with the owner's explicit exception to **keep the Escape minigame**. `tailmouse leash` also remains available for existing protected terminal invitations. New resource commands use TMOUSE/2 and do not depend on the legacy short-link service.

## Build and configure

Use the exact tool versions in [tooling/versions.json](tooling/versions.json). From the repository root:

```sh
corepack enable pnpm
git submodule update --init -- third_party/tailcat
pnpm install --frozen-lockfile
pnpm build
export PATH="$PWD/.artifacts/native:$PATH"
```

Native output is `.artifacts/native/tailmouse`; the static browser distribution is `apps/web/dist/`. Tailcat is embedded in the native executable and browser Wasm. Do not replace its recorded submodule or copy a separately built Wasm into the release.

New resource sessions require the trusted UI's session wildcard origin. Web previews additionally require a content wildcard on a **different registrable domain**. The [resource hosting guide](docs/resource-sharing.md#static-deployment) provides one public JSON configuration consumed by both native and browser code and a static Caddy example. These examples do not establish that a new public deployment already exists.

```sh
export TAILMOUSE_CONFIG=/path/to/tailmouse-config.json
tailmouse cli -- /bin/bash --noprofile --norc -i
tailmouse web http://localhost:5173/admin?tab=1
tailmouse receive ./uploads --max-file 256MiB --max-total 1GiB
```

Create and choose the receive directory yourself. TailMouse never creates arbitrary requested directories or starts an implicit shell. Arguments after `--` are literal argv; shell expansion requires an explicitly launched shell. `dev` requires at least two of CLI, Web and Receive, with at most one resource of each kind.

## Using a workspace

- **CLI:** one owned PTY and child process, one remote input controller, native readonly enforcement, local input taking priority, and same-process reconnection. The browser provides terminal keys, explicit text preparation and screen-reader support. History is bounded to 4 MiB; overflow requests a redraw and visibly reports the recovery limitation.
- **Web:** one declared HTTP(S) origin, same-origin navigation and API requests, streaming responses and main-thread WebSockets. Sharing `/admin` starts there but authorizes the whole origin. Non-loopback targets require `--allow-remote`; additional HTTPS roots use `--ca-file`, never disabled verification.
- **Receive:** one-way uploads with native SHA-256 verification, bounded streaming, quota accounting and atomic non-overwriting commit. Guests cannot browse, read, delete or execute existing files. A completed receipt contains the actual saved name.
- **Dev:** terminal and preview panes, a file drawer and mounted mobile tabs. Copying or inserting an uploaded path is explicit. Insertion only fills a preparation field; it neither sends input nor appends Enter.

Access defaults to one hour and one member, with up to four members supported. `--ttl 0` explicitly keeps access until local termination. `--approval manual` requires a local TTY. Ctrl+] opens management: pause admission, approve a numbered visitor, grant or revoke input, revoke a visitor, rotate the invitation, or end the session. Press Ctrl+] twice to send it literally.

Flags override `TAILMOUSE_*` environment variables, then `--config`/the local version-1 configuration, then defaults. See `tailmouse <command> --help` and the [resource guide](docs/resource-sharing.md) for limits, lifecycle, errors and configuration.

## Security and compatibility

Treat invitation links and QR codes as credentials. New resource invitations authorize their declared capabilities; they do not use Leash's separate access-code flow. Never put invitations into issue reports, process arguments, recordings or diagnostic files. Browser recovery material stays in the trusted origin's per-tab sessionStorage and is erased on terminal outcomes.

The browser transport uses encrypted Tailcat over DERP. This is not an anonymity service, a native-desktop stream or an execution sandbox. A writable terminal has the child's OS authority; a shared web application has its own application authority. A modified trusted UI or browser extension can observe plaintext. The separate content origin cannot access terminal, upload or management capabilities.

Web compatibility is bounded: JavaScript-managed cookies, third-party SSO, arbitrary cross-origin assets, custom Service Workers, nested frames and Worker-owned WebSockets are outside the v1 W1/W2 scope. Restrictive upstream security policy is preserved and may make an application incompatible. A resource invitation is a browser session, not a public HTTP tunnel for curl or webhooks.

Native v1 targets Linux and macOS on amd64/arm64; Windows native resource sharing remains P2. The repository's existing Windows build path does not establish native execution acceptance. Linux automated evidence, historical macOS Leash evidence, desktop browser automation and physical mobile acceptance are distinct. See the [new acceptance ledger](docs/evidence/resource-sharing-acceptance.md) for observed results and remaining checks. This checkout is not a published release.

## Escape and legacy Leash

```sh
tailmouse escape
tailmouse leash -- vim
```

![Escape gameplay](docs/media/escape.gif)

![Legacy Leash Vim session](docs/media/leash-vim.gif)

These historical recordings demonstrate Escape and Leash; they are not evidence for the new Web or Receive resources. Legacy Leash keeps its separate access code, command flags, memory-only credential policy and lifecycle. Its existing [configuration](docs/configuration.md) and [single-origin hosting](docs/web-self-hosting.md) guides remain applicable to those legacy modes.

## Development and release checks

```sh
pnpm exec playwright install
pnpm gate:quick
pnpm gate
```

Gates stop at the first failure. TypeScript statements, branches, functions and lines and Go statements retain an 80% floor. Ordinary weak-network acceptance uses **four representative profiles**; exhaustive matrices are explicit opt-ins. Browser tests use local fixtures and relays, not public relay stress.

The [gate guide](docs/development/gates.md) describes release tool prerequisites. Snapshot builds, notices, SBOMs and checksums are local review artifacts; they do not publish a site or release. Start development with [project memory](context.md), [architecture](docs/architecture.md) and the [active resource change](openspec/changes/implement-resource-sharing-v1/proposal.md).

## License and attribution

TailMouse-owned source is [Apache-2.0](LICENSE), with attribution in [NOTICE](NOTICE) and [third-party notices](THIRD_PARTY_NOTICES.txt). All accompany native and static distributions. `pnpm check:licenses` checks the compiled dependency inventory, including both legacy and resource Wasm. Tailcat source and its gitlink remain read-only unless an update is explicitly requested.

TailMouse is an **unofficial** application built on [Tailcat](https://github.com/tailscale/tailcat), and is not affiliated with or endorsed by Tailscale Inc. Tailscale and Tailcat names and trademarks belong to their respective owners.
