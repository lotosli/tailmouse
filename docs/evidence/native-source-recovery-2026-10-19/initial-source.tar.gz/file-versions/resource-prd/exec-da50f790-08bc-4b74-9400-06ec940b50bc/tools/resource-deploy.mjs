import { cpSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { runPnpm } from './process.mjs';
const root=resolve(import.meta.dirname,'..');
const source=join(root,'apps/web/dist');
const destination=join(root,'.artifacts/resource-deploy/assets');
const action=process.argv[2] ?? 'prepare';
if (!['prepare','check','publish'].includes(action)) throw new Error('Expected prepare, check or publish.');
const manifest=JSON.parse(readFileSync(join(source,'web-manifest.json'),'utf8'));
if (manifest.resourceProtocol?.protocolMajor!==2) throw new Error('Build the current resource release first.');
rmSync(destination,{recursive:true,force:true});mkdirSync(destination,{recursive:true});
// Cloudflare's 25 MiB per-asset limit is smaller than raw Tailcat Wasm. Keep
// both verified compressed encodings; the static Worker negotiates decoding.
for (const entry of readdirSync(source,{recursive:true,withFileTypes:true})) {
 if (!entry.isFile() || entry.name.endsWith('.wasm')) continue;
 const absolute=join(entry.parentPath,entry.name), relative=absolute.slice(source.length+1);
 if (statSync(absolute).size>25*1024*1024) throw new Error('Static object exceeds Cloudflare asset limit.');
 mkdirSync(resolve(destination,relative,'..'),{recursive:true});cpSync(absolute,join(destination,relative));
}
if (action!=='prepare') runPnpm(['--filter','@tailmouse/link-edge','exec','wrangler','deploy','--config','../../deploy/resource/wrangler.jsonc',...(action==='check'?['--dry-run','--outdir','../../.artifacts/resource-deploy/worker']:[])]);
process.stdout.write(action==='publish'?'Single-origin test deployment published.\n':'Single-origin static deployment prepared.\n');
