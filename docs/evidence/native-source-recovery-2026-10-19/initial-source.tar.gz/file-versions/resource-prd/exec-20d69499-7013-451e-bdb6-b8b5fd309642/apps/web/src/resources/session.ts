import { ResourceTransport } from '../transport/tailcat/resource.ts';
import { strictObject } from '../protocol/values.ts';
import { ResourceWire, ResourceError, CHUNK } from './wire.ts';
import { saveRecovery, eraseRecovery, type Recovery } from './invitation.ts';
export interface SharedResource { id: 'cli' | 'web' | 'receive'; state: string; readOnly?: boolean; initialPath?: string; origin?: string; maxFile?: number; maxTotal?: number; maxFiles?: number }
export interface ResourceManifest { title: string; resources: SharedResource[]; contentOrigin: string; transport: string }
export type SessionStatus = 'connecting' | 'waiting' | 'active' | 'reconnecting' | 'disconnected' | 'closed';
export interface SessionView { status: SessionStatus; message: string; manifest: ResourceManifest | null; controller: boolean; expiring: boolean }
export interface UploadReceipt { type: 'upload.completed'; upload: string; name: string; path: string; size: number; sha256: string }
export function parseReceipt(value: Record<string, unknown>): UploadReceipt {
  if (value.type !== 'upload.completed' || typeof value.upload !== 'string' || !/^[a-f0-9]{32}$/u.test(value.upload) || typeof value.name !== 'string' || value.name.length > 256 || /[/\\\x00-\x1f]/u.test(value.name) || typeof value.path !== 'string' || value.path.startsWith('/') || value.path.includes('..') || value.path.includes('\\') || typeof value.size !== 'number' || !Number.isSafeInteger(value.size) || value.size < 0 || typeof value.sha256 !== 'string' || !/^[a-f0-9]{64}$/u.test(value.sha256)) throw new Error('Invalid upload receipt.');
  return value as unknown as UploadReceipt;
}
export class ResourceSession {
  readonly recovery: Recovery;
  readonly #storage: Storage;
  #transport: ResourceTransport | undefined;
  #control: ResourceWire | undefined;
  #streams = new Set<ResourceWire>();
  #closed = false;
  #connecting = false;
  #generation = 0;
  #view: SessionView = { status: 'connecting', message: 'Connecting to the host…', manifest: null, controller: false, expiring: false };
  #listeners = new Set<(view: SessionView) => void>();
  constructor(recovery: Recovery, storage: Storage) { this.recovery = recovery; this.#storage = storage; }
  get view(): SessionView { return this.#view; }
  subscribe(listener: (view: SessionView) => void): () => void { this.#listeners.add(listener); listener(this.#view); return () => this.#listeners.delete(listener); }
  #update(values: Partial<SessionView>): void { this.#view = { ...this.#view, ...values }; for (const listener of this.#listeners) listener(this.#view); }
  async connect(): Promise<void> {
    if (this.#closed || this.#connecting) return;
    this.#connecting = true; const generation = ++this.#generation; const deadline = performance.now() + 60_000; let attempt = 0;
    try {
      while (!this.#closed && generation === this.#generation) {
        try {
          this.#update({ status: attempt === 0 ? 'connecting' : 'reconnecting', controller: false, message: attempt === 0 ? 'Loading transport and connecting…' : 'Reconnecting; pending input and requests were discarded.' });
          if (this.#transport === undefined) {
            const transport = new ResourceTransport(); this.#transport = transport;
            this.recovery.key = await transport.start(this.recovery.invitation.address, this.recovery.key);
            saveRecovery(this.#storage, this.recovery);
          }
          const wire = new ResourceWire(await this.#transport.dial()); this.#control = wire;
          await wire.stream.write(new TextEncoder().encode('TMOUSE/2\n'));
          const validGrant = this.recovery.member !== '' && this.recovery.grant !== '' && this.recovery.expires > Date.now();
          await wire.json({ type: 'hello', version: 2, session: this.recovery.invitation.session, channel: 'control', ...(validGrant ? { member: this.recovery.member, grant: this.recovery.grant } : { token: [REDACTED_SECRET] }) });
          let welcome = await wire.object();
          if (welcome.type === 'waiting') { this.#update({ status: 'waiting', message: 'Waiting for the host to approve this visit.' }); welcome = await wire.object(); }
          this.#acceptWelcome(welcome);
          this.#update({ status: 'active', message: 'Connected · encrypted Tailcat over DERP' });
          void this.#readControl(wire, generation);
          return;
        } catch (error) {
          if (error instanceof ResourceError && ['UNAUTHORIZED','EXPIRED'].includes(error.code)) { this.close(error.code === 'EXPIRED' ? 'This session has expired.' : 'Access was revoked or the invitation is no longer valid.'); return; }
          this.#control = undefined;
          if (performance.now() >= deadline) { this.#update({ status: 'disconnected', message: 'Connection could not be restored within 60 seconds. Retry when ready.' }); return; }
          attempt++;
          await new Promise<void>((resolve) => setTimeout(resolve, Math.min(5000, 300 * 2 ** Math.min(attempt, 4)) * (0.8 + Math.random() * 0.4)));
        }
      }
    } finally { this.#connecting = false; }
  }
  #acceptWelcome(value: Record<string, unknown>): void {
    const m = value.manifest as ResourceManifest | undefined;
    if (value.type !== 'welcome' || value.version !== 2 || typeof value.member !== 'string' || !/^[a-f0-9]{32}$/u.test(value.member) || typeof value.grant !== 'string' || !/^[A-Za-z0-9_-]{43}$/u.test(value.grant) || typeof value.expires !== 'number' || !Number.isSafeInteger(value.expires) || m === undefined || typeof m.title !== 'string' || !Array.isArray(m.resources) || m.resources.length < 1 || m.resources.length > 3 || new Set(m.resources.map((r) => r.id)).size !== m.resources.length || m.resources.some((r) => !['cli','web','receive'].includes(r.id))) throw new Error('Incompatible host manifest.');
    if (m.resources.some((r) => r.id === 'web')) {
      const origin = new URL(m.contentOrigin);
      if (origin.protocol !== 'https:' || origin.origin !== m.contentOrigin || !origin.hostname.startsWith(`a-${this.recovery.invitation.session}-web.`) || origin.hostname === location.hostname || origin.hostname.endsWith(`.${location.hostname}`)) throw new Error('Invalid content isolation origin.');
    }
    this.recovery.member = value.member; this.recovery.grant = value.grant; this.recovery.expires = value.expires;
    saveRecovery(this.#storage, this.recovery); this.#update({ manifest: m });
  }
  async #readControl(wire: ResourceWire, generation: number): Promise<void> {
    let liveness: ReturnType<typeof setTimeout>;
    const refresh = (): void => { clearTimeout(liveness); liveness = setTimeout(() => { void wire.close(); }, 15_000); };
    refresh();
    try {
      while (!this.#closed && generation === this.#generation) {
        const value = await wire.object();
        if (value.type === 'ping' && Number.isSafeInteger(value.seq)) { refresh(); await wire.json({ type: 'pong', seq: value.seq }); }
        else if (value.type === 'state' && typeof value.controller === 'boolean') this.#update({ controller: value.controller, expiring: value.expiring === true });
        else if (value.type === 'close') { this.close('The host ended this session.'); return; }
        else throw new Error('Unexpected control message.');
      }
    } catch {
      if (!this.#closed && generation === this.#generation) {
        this.#update({ status: 'reconnecting', controller: false });
        await this.#closeStreams();
        void this.connect();
      }
    } finally { clearTimeout(liveness!); }
  }
  async open(channel: 'terminal' | 'http' | 'websocket' | 'upload', resource: SharedResource['id']): Promise<ResourceWire> {
    if (this.#closed || this.#view.status !== 'active' || this.#transport === undefined || !this.#view.manifest?.resources.some((r) => r.id === resource)) throw new Error('Resource unavailable.');
    const wire = new ResourceWire(await this.#transport.dial());
    try {
      await wire.stream.write(new TextEncoder().encode('TMOUSE/2\n'));
      await wire.json({ type: 'hello', version: 2, session: this.recovery.invitation.session, channel, resource, member: this.recovery.member, grant: this.recovery.grant });
      this.#streams.add(wire); return wire;
    } catch (error) { await wire.close(); throw error; }
  }
  async release(wire: ResourceWire): Promise<void> { this.#streams.delete(wire); await wire.close(); }
  async upload(file: File, signal: AbortSignal, progress: (state: string, received: number) => void): Promise<UploadReceipt> {
    const wire = await this.open('upload', 'receive'); const transport = this.#transport!;
    const abort = (): void => { void wire.close(); }; signal.addEventListener('abort', abort, { once: true });
    let hash: number | undefined;
    try {
      if (signal.aborted) throw new Error('Upload canceled.');
      await wire.json({ type: 'upload.begin', name: file.name, size: file.size });
      const ready = await wire.object(); if (ready.type !== 'upload.ready' || typeof ready.upload !== 'string') throw new Error('Upload not accepted.');
      const id = await transport.call('hash.start', 0, null); if (typeof id !== 'number') throw new Error('Hasher unavailable.'); hash = id;
      progress('uploading', 0);
      for (let offset = 0; offset < file.size;) {
        if (signal.aborted) throw new Error('Upload canceled.');
        const bytes = new Uint8Array(await file.slice(offset, offset + CHUNK).arrayBuffer());
        await transport.call('hash.update', hash, bytes); await wire.write(2, bytes);
        const ack = await wire.object(); offset += bytes.length;
        if (ack.type !== 'upload.progress' || ack.received !== offset) throw new Error('Invalid upload acknowledgement.');
        progress('uploading', offset);
      }
      progress('verifying', file.size);
      const digest = await transport.call('hash.finish', hash, null); hash = undefined;
      await wire.json({ type: 'upload.finish', sha256: digest });
      const receipt = parseReceipt(await wire.object());
      if (receipt.upload !== ready.upload || receipt.size !== file.size || receipt.sha256 !== digest) throw new Error('Invalid committed receipt.');
      progress('completed', file.size); return receipt;
    } finally {
      signal.removeEventListener('abort', abort);
      if (hash !== undefined) await transport.call('hash.cancel', hash, null).catch(() => undefined);
      await this.release(wire).catch(() => undefined);
    }
  }
  async #closeStreams(): Promise<void> { const streams = [...this.#streams]; this.#streams.clear(); await Promise.allSettled(streams.map((s) => s.close())); }
  close(message = 'Session closed.'): void {
    if (this.#closed) return;
    this.#closed = true; this.#generation++; this.#transport?.close(); this.#transport = undefined; this.#streams.clear(); this.#control = undefined;
    eraseRecovery(this.#storage); this.recovery.key = ''; this.recovery.grant = ''; this.recovery.invitation.token = ''; this.recovery.invitation.address = '';
    this.#update({ status: 'closed', controller: false, manifest: null, message });
  }
}
export function frameObject(data: Uint8Array): Record<string, unknown> { return strictObject(data); }
