/// <reference lib="webworker" />

// Only this adapter speaks to the TailMouse-owned Go/Wasm bridge. Worker
// requests come exclusively from the trusted parent, never from preview frames.
interface ResourceRuntime {
  Go?: new () => { importObject: WebAssembly.Imports; run(instance: WebAssembly.Instance): Promise<void> };
  tailmouseResourceCall?: (op: string, id: number, value: unknown) => Promise<unknown>;
}
const runtime = globalThis as typeof globalThis & ResourceRuntime;
const scope = globalThis as unknown as DedicatedWorkerGlobalScope;
let loading: Promise<void> | undefined;
async function load(assets: { runtime: string; wasm: string }): Promise<void> {
  for (const value of [assets.runtime, assets.wasm]) {
    const url = new URL(value, scope.location.href);
    if (url.origin !== scope.location.origin) throw new Error('ASSET_ORIGIN');
  }
  await import(/* @vite-ignore */ assets.runtime);
  if (runtime.Go === undefined) throw new Error('RUNTIME_MISSING');
  const go = new runtime.Go();
  const result = await WebAssembly.instantiateStreaming(fetch(assets.wasm, { credentials: 'omit', referrerPolicy: 'no-referrer' }), go.importObject);
  void go.run(result.instance).catch(() => scope.postMessage({ fatal: true }));
  if (runtime.tailmouseResourceCall === undefined) throw new Error('BRIDGE_MISSING');
}
scope.addEventListener('message', (event: MessageEvent<unknown>) => {
  const message = event.data as { id: number; op: string; stream: number; value: unknown; assets?: { runtime: string; wasm: string } };
  if (!Number.isSafeInteger(message?.id) || typeof message.op !== 'string') return;
  void (async () => {
    try {
      if (message.op === 'load') {
        if (message.assets === undefined) throw new Error('ASSETS_MISSING');
        loading ??= load(message.assets);
        await loading;
        scope.postMessage({ id: message.id, ok: true });
        return;
      }
      await loading;
      if (runtime.tailmouseResourceCall === undefined) throw new Error('BRIDGE_MISSING');
      const value = await runtime.tailmouseResourceCall(message.op, message.stream, message.value);
      if (value instanceof Uint8Array) scope.postMessage({ id: message.id, ok: true, value }, [value.buffer]);
      else scope.postMessage({ id: message.id, ok: true, value });
    } catch {
      scope.postMessage({ id: message.id, ok: false });
    }
  })();
});
