import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { run } from './process.mjs';

const root = resolve(import.meta.dirname, '..');
const output = join(root, '.artifacts', 'resource-bridge');
const { go } = JSON.parse(readFileSync(join(root, 'tooling/versions.json'), 'utf8'));
mkdirSync(output, { recursive: true });
run('go', ['build', '-trimpath', '-o', join(output, 'resource.wasm'), './apps/cli/internal/transport/tailcat/wasm'], {
  cwd: root,
  env: { GOOS: 'js', GOARCH: 'wasm', CGO_ENABLED: '0', GOTOOLCHAIN: `go${go}` },
});
const bytes = readFileSync(join(output, 'resource.wasm'));
const tailcatRevision = run('git', ['rev-parse', 'HEAD'], { cwd: join(root, 'third_party/tailcat'), capture: true }).stdout.trim();
writeFileSync(join(output, 'manifest.json'), JSON.stringify({ schemaVersion: 1, frontendMajor: 1, protocolMajor: 2, tailcatRevision, goVersion: `go${go}`, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') }, null, 2) + '\n');
